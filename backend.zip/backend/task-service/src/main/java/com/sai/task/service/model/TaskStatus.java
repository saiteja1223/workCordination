package com.sai.task.service.model;

public enum TaskStatus {
    PENDING("PENDING"),
    ASSIGNED("ASSIGNED"),
        DONE("DONE");

    TaskStatus(String pending) {
    }
}
